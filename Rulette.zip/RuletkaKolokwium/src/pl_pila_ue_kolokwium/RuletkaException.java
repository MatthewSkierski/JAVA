package pl_pila_ue_kolokwium;

public class RuletkaException extends Exception {

	public RuletkaException(String message) {
		super(message);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
