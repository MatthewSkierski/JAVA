package pl_pila_ue_kolokwium;



import java.util.Random;
import java.util.Scanner;

public class Ruletka {

	public Ruletka() {

	}

	private Scanner scan = new Scanner(System.in);
	private Random generator = new Random();
	private int liczbaZetonow = 100;
	private int liczbaRuletki = 0;
	private int liczbaJeden = 0;
	private int liczbaDwa = 0; 
	
	public void losowaLiczba(int liczbaRuletki) {

		liczbaRuletki = generator.nextInt(36);
		this.liczbaRuletki = liczbaRuletki;

	}

	private void zapytajLiczby(int min, int max, String pytanie) throws RuletkaException {

		while (true) {
			System.out.println(pytanie + ": ");
			try {
			String opcjaString = scan.next();		
			int liczbaJeden = Integer.parseInt(opcjaString);
			this.liczbaJeden = liczbaJeden;
			String x = scan.next();
			int liczbaDwa = Integer.parseInt(x);
			this.liczbaDwa = liczbaDwa;

			if (liczbaJeden <= max && liczbaJeden >= min && liczbaDwa <= max && liczbaDwa >= min  ) {
				if(liczbaJeden != liczbaDwa) {
					break;
				}else {
					throw new RuletkaException("Liczby musz� by� r�ne");
				}

			} else {
				throw new RuletkaException("Liczba musi byc z przedzialu " + min + "-" + max + '!');
				

			}
			
			}catch(NumberFormatException e) {
				System.out.println(e.getMessage()+ " Nie jest liczb� ca�kowit�");
			}
		
	}
	}
	
	

	public void pobierzLiczbyOdGracza() {

		try {
			zapytajLiczby(0, 36, "Podaj liczby");
		} catch (RuletkaException e) {			
			System.out.println(e.getMessage());
			pobierzLiczbyOdGracza();
			
		}
	

	}

	public int sprawdzWynik(int liczbaDwa, int liczbaJeden, int liczbaRuletki, int liczbaZetnow) {

		if (liczbaDwa == liczbaRuletki || liczbaJeden == liczbaRuletki) {
			System.out.println("Brawo trafi�e� liczb� " + liczbaRuletki + " Otrzymujesz 60 �eton�w!");
			dodajWynik(liczbaZetonow);
			return liczbaZetnow;

		}
		System.out.println("Nie trafi�e� liczb. Liczba z ruletki to " + liczbaRuletki + "." + " Masz tyle �eton�w : "
				+ liczbaZetnow);
		return liczbaZetnow;

	}

	public int odejmijOdWyniku(int liczbaZetonow) {

		liczbaZetonow -= 20;
		this.liczbaZetonow = liczbaZetonow;
		return liczbaZetonow;
	}

	public int dodajWynik(int liczbaZetonow) {
		liczbaZetonow += 60;
		this.liczbaZetonow = liczbaZetonow;
		return liczbaZetonow;
	}

	public int podajLiczbeZetonow(int liczbaZetonow) {
		this.liczbaZetonow = liczbaZetonow;
		return liczbaZetonow;
	}

	public void wykonajOpcje(int opcja) {
		switch (opcja) {
		case 0:
			zakonczGre();

			break;
		case 1:
			rozegrajGre();

			break;
		}

	}

	public int pobierzOpcje() {
		int opcja = scan.nextInt();
		if (opcja > 2) {
			System.err.println("Poda�e� z�� liczb� podaj jeszcze raz liczb�");
			return pobierzOpcje();
		}
		return opcja;
	}

	public void wyswietlMenu() {
		System.out.println("Co chcesz zrobi� ?");
		System.out.println("(1)Zagraj w ruletk� .");

	}

	private void zakonczGre() {
		System.out.println("Zako�czy�e� gr� z " + podajLiczbeZetonow(liczbaZetonow) + " �etonami");
		System.exit(0);

	}

	public void wlacz() {

		wyswietlMenu();
		int opcja = pobierzOpcje();
		wykonajOpcje(opcja);
	}

	public void dalszaGra() {
		int opcja = pobierzOpcje();
		wykonajOpcje(opcja);

	}

	private void czyGramDalej() {
		System.out.println("Czy chesz dalej obstawia� ?");
		System.out.println("(1)  Gram dalej");
		System.out.println("(0) Rezygnuj�");

	}

	public void rozegrajGre() {
		odejmijOdWyniku(liczbaZetonow);
		System.out.println("Obstaw dwie liczby z zakresu 0-36");
		pobierzLiczbyOdGracza();
		losowaLiczba(liczbaRuletki);
		sprawdzWynik(liczbaDwa, liczbaJeden, liczbaRuletki, liczbaZetonow);
		sprawdzanieLiczbyZetonow(liczbaZetonow);
		czyGramDalej();
		dalszaGra();
	}

	private void sprawdzanieLiczbyZetonow(int liczbaZetonow) {
		if (liczbaZetonow <= 0) {
			System.out.println("Koniec gry sko�czy�y Ci si� �etony. " + "Do widzenia");
			System.exit(0);
		}

	}

	public static void main(String[] args) {
		Ruletka ruletka = new Ruletka();
		ruletka.wlacz();

	}
}
