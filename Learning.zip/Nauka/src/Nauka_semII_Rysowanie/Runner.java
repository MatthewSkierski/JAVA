package Nauka_semII_Rysowanie;


public class Runner {

	public static void main(String[] args) {
		AppFrame f = new AppFrame();
		f.setVisible(true);
	}

}
