package obliczanieDwochLiczb;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class AppFrame extends JFrame implements ActionListener {

	public JTextField poleRzut = new JTextField();
	public JTextField poleKosci = new JTextField();
	public JTextField poleWynik = new JTextField();
	public JButton liczButton = new JButton("Start Symulacji");
	int liczbaScian;
	int liczbaRzutow;
	public ArrayList<Random> lista = new ArrayList<Random>();
	Random generator = new Random();
	
	public JPanel mojPanel;
	
	public AppFrame() {
		setTitle("Obliczanie liczb");
		setSize(700,700);
		setResizable(false);
	
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		mojPanel = new JPanel();
		add(mojPanel);
		initGui();
	}


	private void initGui() {
		mojPanel.removeAll();
		GridLayout ustawienie = new GridLayout(4, 1);
		mojPanel.setLayout(ustawienie);
		mojPanel.add(poleRzut);
		mojPanel.add(poleKosci);
		mojPanel.add(liczButton);
		liczButton.addActionListener(this);
		mojPanel.add(poleWynik);
		pack();

		
		
	}


	public void actionPerformed(ActionEvent e) {
	Object zrodlo = e.getSource();
	if(zrodlo == liczButton) {
		symulacja();
	}
	
		
	}


	private void symulacja() {
		String y = poleKosci.getText();
		liczbaScian = Integer.parseInt(y);
		String x = poleRzut.getText();
		liczbaRzutow = Integer.parseInt(x);
		
		for(int i = 0 ;i < liczbaRzutow;i++) {
		int z = generator.nextInt(liczbaScian+1);
			if(z == 1 ) {
			lista.add(generator);			
		}
			}
		double f = lista.size();
		double wynik = f/liczbaRzutow;
		String k;
		k = String.valueOf(wynik);
		poleWynik.setText(k);
		
		
	}
	
}

