package SortowanieLiczb;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class AppFrame extends JFrame implements ActionListener {	
	private static final long serialVersionUID = 1L;
	public JPanel panel;
	public JButton sortButton = new JButton("Sortuj");
	public JTextField poleJeden = new JTextField();
	public JTextField poleDwa = new JTextField();
	public JTextField poleTrzy = new JTextField();
	public ArrayList<Integer> lista = new ArrayList();

	public AppFrame() {
		setTitle("Sortownia");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		panel = new JPanel();
		add(panel);
		initGui();
		
		
		
	}

	
	private void initGui() {
		panel.removeAll();
		GridLayout ustawienie = new GridLayout(1, 4);
		panel.setLayout(ustawienie);
		panel.add(poleJeden);
		panel.add(poleDwa);
		panel.add(poleTrzy);
		panel.add(sortButton);
		sortButton.addActionListener(this);
		pack();
		
		
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		Object zrodlo = e.getSource();
		if(zrodlo == sortButton) {
			sortowanieLiczb();
		}
		
	}


	private void sortowanieLiczb() {
		String textJeden = poleJeden.getText();
		String textDwa = poleDwa.getText();
		String textTrzy = poleTrzy.getText();
		try {
		int liczbaJeden = Integer.parseInt(textJeden);		
		int liczbaDwa = Integer.parseInt(textDwa);		
		int liczbaTrzy = Integer.parseInt(textTrzy);
		lista.add(liczbaJeden);
		lista.add(liczbaDwa);
		lista.add(liczbaTrzy);
        Collections.sort(lista);
		
		String x = String.valueOf(lista.get(0));
		poleJeden.setText(x);
		String y = String.valueOf(lista.get(1));
		poleDwa.setText(y);
		String z = String.valueOf(lista.get(2));
		poleTrzy.setText(z);
		}catch(IndexOutOfBoundsException e) {
			poleJeden.setText("POdaj poprawn� liczb�");
		}catch(NumberFormatException e) {
			JOptionPane.showMessageDialog(null,  "Podaj poprawne liczby",
					"Warrning Message", JOptionPane.OK_CANCEL_OPTION);
		}
		
		
		
		
	
		

		
	}

}
