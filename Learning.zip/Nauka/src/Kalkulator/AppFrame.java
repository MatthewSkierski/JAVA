package Kalkulator;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class AppFrame extends JFrame implements ActionListener{
	public JPanel panel;
	public JTextField poleJeden = new JTextField();
	public JTextField poleDwa = new JTextField();
	public JTextField poleWyraz = new JTextField();
	public JTextField poleWynik = new JTextField();
	public JButton przycisk = new JButton("Oblicz");
	
	public AppFrame() {
		setTitle("Kalkulator");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(700, 700);
		setResizable(false);
		setLocationRelativeTo(null);
		panel = new JPanel();
		add(panel);
		initGui();
		
	}
	
	private void initGui() {
		panel.removeAll();
		GridLayout ustawienie = new GridLayout(1, 5);
		panel.setLayout(ustawienie);
		panel.add(poleJeden);
		panel.add(poleDwa);
		panel.add(poleWyraz);
		panel.add(przycisk);
		przycisk.addActionListener(this);
		panel.add(poleWynik);
		
		pack();
		
	}

	public void actionPerformed(ActionEvent e) {
		Object zrodlo = e.getSource();
		
		if(zrodlo == przycisk) {
		String slowo =poleWyraz.getText();
		String slowoJeden= poleJeden.getText();
		String slowoDwa = poleDwa.getText();
		int jeden = Integer.parseInt(slowoJeden);
		int dwa = Integer.parseInt(slowoDwa);
		
		switch (slowo){
		case "dodaj":
			
			int wynik = jeden+dwa;
			String wynikSlowo= String.valueOf(wynik);
			poleWynik.setText(wynikSlowo);
			
			break;
		case"odejmij":
			int wynikOdejmowanie = jeden-dwa;
			String wynikSlowoOdejmowanie= String.valueOf(wynikOdejmowanie);
			poleWynik.setText(wynikSlowoOdejmowanie);
			
			break;
		case"mnoz":
			int wynikmnozenie = jeden*dwa;
			String wynikSlowomnozenie= String.valueOf(wynikmnozenie);
			poleWynik.setText(wynikSlowomnozenie);
			break;
	
			
		
		}
		}
		
	}

}
