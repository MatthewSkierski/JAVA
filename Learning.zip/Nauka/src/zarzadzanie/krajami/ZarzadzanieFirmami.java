package zarzadzanie.krajami;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class ZarzadzanieFirmami {

	private ArrayList<Firma> firmy = new ArrayList<Firma>();
	private boolean wlaczony = true;
	private Scanner scan = new Scanner(System.in);
	private Random rand = new Random();

	private List<Firma> wczytajFirme() throws IOException {
		File plik = new File("pliki/kursy.txt");
		FileReader fr = new FileReader(plik);
		BufferedReader br = new BufferedReader(fr);
		List<Firma> firmy = new ArrayList<Firma>();

		for (String linia = br.readLine(); linia != null; linia = br.readLine()) {
			String[] daneFirmy = linia.split(";");

			String nazwa = daneFirmy[0];
			double kursStartowy = Double.parseDouble(daneFirmy[1]);
			double kursKoncowy = Double.parseDouble(daneFirmy[2]);

			Firma firma;
			try {
				firma = new Firma(nazwa, kursStartowy, kursKoncowy);
				firmy.add(firma);
			} catch (FirmaException e) {
				System.err.println(e.getMessage());

			}

		}
		br.close();
		return firmy;

	}

	private void wyswietlMenu() {
		StringBuilder sb = new StringBuilder();
		sb.append("1.Wy�wietl Firmy");
		sb.append("\n2.Posortuj Firmy Alfabatycznie");
		sb.append("\n3.Posortuj Firmy Od Najwy�szego Kursu Startowego");
		sb.append("\n4.Posortuj Firmy Od Najwy�szego Kursu Ko�cowego");
		sb.append("\n5.Dodaj Firme");
		sb.append("\n6.Usu� Firme");
		sb.append("\n7.Oblicz ile firma zarobi�a/straci�a");
		sb.append("\n8.Zako�cz Dzia�alnie Programu");
		sb.append("\n9.Wy�wietl 5 losowych firm");
		sb.append("\n10.Wy�wietl firm� kt�ra zarobi�a najwi�cej");
		sb.append("\n11.Wy�wietl firm� kt�ra straci�a najwi�cej");
		sb.append("\n12.Wy�wietl szczeg�owe listy");
		sb.append("\nWybierz Opcj�");

		System.out.println(sb.toString());
	}

	private void rozpocznijProgam() {
		try {
			firmy = (ArrayList<Firma>) wczytajFirme();
			while (wlaczony) {
				wyswietlMenu();
				int opcja = pobierzOpcje();
				wykonajOpcje(opcja);
			}

		} catch (IOException e) {
			System.err.println(e.getMessage());
		}

	}

	private int pobierzOpcje() {
		String opcjaString = scan.nextLine();
		try {
			int opcja = Integer.parseInt(opcjaString);
			return opcja;
		} catch (NumberFormatException e) {
			System.err.println("Nie jest to liczba " +"'"+ opcjaString+"'" + " Podaj ponownie opcj�");
			return pobierzOpcje();
		}
		
	}

	private void wykonajOpcje(int opcja) {		
	
		switch (opcja) {
		case 1:
			wyswietlFirmy();
			break;
		case 2:
			posortujFirmyAlfabetycznie();
			break;
		case 3:
			posortujFirmy();
			break;
		case 4:
			posortujFirmyKoniec();
			break;

		case 5:
			try {
				try {
					dodajFirme();
				} catch (IOException e) {

					e.printStackTrace();
				}
			} catch (FirmaException e) {

				e.printStackTrace();
			}
			break;
		case 6:
			try {
				try {
					usunFirme(firmy);
				} catch (IOException e) {

					e.printStackTrace();
				}
			} catch (FirmaException e) {

				e.printStackTrace();
			}
			break;
		case 7:
			obliczanieZysku();
			break;
		case 8:
			wlaczony = false;
			break;
		case 9:
			losowaFirma();
			break;
		case 10:
			najwiekszyZysk();
			break;
		case 11:
			najwiekszaStrata();
			break;
		case 12:
			wyswietlSzczegoloweListy();
			break;
		default:
			System.err.println("Z�a opcja zosta�a wybrana " + opcja);
			break;

		}
	}

	private void wyswietlSzczegoloweListy() {
		System.out.println("Podaj numer listy, kt�r� chcesz wy�wietli�");
		szczegoloweListy();
		int opcja = pobierzOpcje();
		switch (opcja) {
		case 1:
			wyswietlFirmyZyskiem();
			break;
		case 2:
			wyswietlFirmyNeutralne();
			break;
		case 3:
			wyswietlFirmyZStrata();
			break;
		default:
			System.err.println("Podano nie prawid�ow� opcj� " + opcja);
			wyswietlSzczegoloweListy();
		}

	}

	private void wyswietlFirmyZStrata() {
		for (Firma firma : firmy) {

			double zysk = firma.getKursKoncowy() - firma.getKursStartowy();

			if (zysk < 0) {
				String infoStrata = " Kurs firmy " + firma.getNazwa() + " zmala� o  " + zysk;

				System.out.println(infoStrata);
			}
		}

	}

	private void wyswietlFirmyNeutralne() {
		for (Firma firma : firmy) {

			double zysk = firma.getKursKoncowy() - firma.getKursStartowy();

			if (zysk == 0) {
				String infoNeutral = " Kurs firmy " + firma.getNazwa() + " pozosta� nie zmienny  " + zysk;

				System.out.println(infoNeutral);

			}

		}

	}

	private void wyswietlFirmyZyskiem() {
		for (Firma firma : firmy) {

			double zysk = firma.getKursKoncowy() - firma.getKursStartowy();
			if (zysk > 0) {
				String infoZysk = " Kurs firmy " + firma.getNazwa() + " wzr�s�  o  " + zysk;

				System.out.println(infoZysk);
			}

		}
	}

	private void szczegoloweListy() {
		StringBuilder sb = new StringBuilder();
		sb.append(" 1. Firmy, kt�re zarobi�y");
		sb.append("\n 2. Firmy, kt�rych kurs pozosta� niezmienny");
		sb.append("\n 3. Firmy, kt�re straci�y");
		System.out.println(sb.toString());

	}

	private void najwiekszaStrata() {
		Firma x = null;
		for (Firma strata : this.firmy) {
			if (x == null || strata.wspolczynnikStraty() < x.wspolczynnikStraty()) {
				x = strata;
			}
		}
		double strata = x.getKursKoncowy() - x.getKursStartowy();
		System.out.println(x.getNazwa() + " Kurs Startowy " + x.getKursStartowy() + " Kurs ko�cowy "
				+ x.getKursKoncowy() + " Strata wynios�a " + strata);

	}

	private void najwiekszyZysk() {
		Firma x = null;
		for (Firma zysk : this.firmy) {
			if (x == null || zysk.wspolczynnik() < x.wspolczynnik()) {
				x = zysk;
			}
		}

		double zarobek = -(x.getKursStartowy() - x.getKursKoncowy());
		System.out.println(x.getNazwa() + " Kurs Startowy " + x.getKursStartowy() + " Kurs ko�cowy "
				+ x.getKursKoncowy() + " Zarobek wyni�s� " + zarobek);
	}

	private void losowaFirma() {
		int i = 0;
		while (i < 5) {

			Firma losowaFirma = this.firmy.get(rand.nextInt(this.firmy.size()));
			System.out.println(losowaFirma.getNazwa() + (" Kurs startowy ") + losowaFirma.getKursStartowy()
					+ (" Kurs ko�cowy ") + losowaFirma.getKursKoncowy());
			i++;
		}
	}

	private void obliczanieZysku() {

		for (Firma firma : firmy) {

			double zysk = firma.getKursKoncowy() - firma.getKursStartowy();
			if (zysk > 0) {
				String infoZysk = " Kurs firmy " + firma.getNazwa() + " wzr�s�  o  " + zysk;

				System.out.println(infoZysk);
			}
			if (zysk < 0) {
				String infoStrata = " Kurs firmy " + firma.getNazwa() + " zmala� o  " + zysk;

				System.out.println(infoStrata);
			}
			if (zysk == 0) {
				String infoNeutral = " Kurs firmy " + firma.getNazwa() + " pozosta� nie zmienny  " + zysk;

				System.out.println(infoNeutral);

			}

		}

	}

	private void posortujFirmyAlfabetycznie() {
		Comparator<Firma> comp = Comparator.comparing(Firma::getNazwa);
		Collections.sort(firmy, comp);

	}

	private void posortujFirmyKoniec() {
		Comparator<Firma> comp = Comparator.comparingDouble(Firma::getKursKoncowy).reversed();
		Collections.sort(firmy, comp);

	}

	private void usunFirme(List<Firma> firmy) throws FirmaException, IOException {
		System.out.println("Podaj nazw� firmy, kt�r� chcesz usun�� :");
		String nazwa = scan.nextLine().toUpperCase();

		Firma firma = new Firma(nazwa, 0, 0);
		if (this.firmy.contains(firma)) {
			this.firmy.remove(firma);

			System.out.println("Firma " + nazwa + " zosta�a usuni�ta");
			// zapisanie zmian w pliku
			String lokalizacja = "pliki/kursy.txt";
			File plik = new File(lokalizacja);
			FileWriter fw = new FileWriter(plik);
			BufferedWriter bw = new BufferedWriter(fw);

			for (Firma u : firmy) {
				bw.write(u.getNazwa());
				bw.write(";");
				bw.write(u.getKursStartowy() + "");
				bw.write(";");
				bw.write(u.getKursKoncowy() + "");
				bw.write(";");
				bw.write("\n");
			}

			bw.flush();
			bw.close();

		} else {
			System.err.println("Taka firma nie istneje " + nazwa);
		}

	}

	private void dodajFirme() throws FirmaException, IOException {
		String nazwa = askString("Podaj nazwe firmy");
		double kursStartowy = askDouble(0, Double.MAX_VALUE, "Podaj Kurs Startowy");
		double kursKoncowy = askDouble(0, Double.MAX_VALUE, "Podaj Kurs Ko�cowy");

		Firma f = new Firma(nazwa.toUpperCase(), kursStartowy, kursKoncowy);
		firmy.add(f);
		System.out.println("Dodano firm� : " + f.getNazwa());

		// zapisywanie do pliku zmian
		String lokalizacja = "pliki/kursy.txt";
		File plik = new File(lokalizacja);
		FileWriter fw = new FileWriter(plik);
		BufferedWriter bw = new BufferedWriter(fw);

		for (Firma u : firmy) {
			bw.write(u.getNazwa());
			bw.write(";");
			bw.write(u.getKursStartowy() + "");
			bw.write(";");
			bw.write(u.getKursKoncowy() + "");
			bw.write(";");
			bw.write("\n");
		}

		bw.flush();
		bw.close();

	}

	private void posortujFirmy() {
		Comparator<Firma> comp = Comparator.comparingDouble(Firma::getKursStartowy).reversed();
		Collections.sort(firmy, comp);

	}

	private void wyswietlFirmy() {
		for (Firma firma : firmy) {
			String info = "Nazwa Firmy : " + firma.getNazwa() + " Kurs Startowy : " + firma.getKursStartowy()
					+ " Kurs ko�cowy : " + firma.getKursKoncowy();
			System.out.println(info);
		}

	}

	private double askDouble(double min, double max, String pytanie) {
		double x;
		while (true) {
			try {
				System.out.print(pytanie + ": ");
				x = Double.parseDouble(scan.nextLine());
				if (x <= max && x >= min)
					break;
				System.out.println("Liczba musi byc z przedzialu " + min + "-" + max + '!');
			} catch (NumberFormatException e) {
				System.err.println("Podano nieprawidlowa liczbe!");
			}
		}
		return x;
	}

	private String askString(String pytanie) {
		String x;
		while (true) {
			System.out.print(pytanie + ": ");
			x = scan.nextLine().toUpperCase();

			if (!x.isBlank())
				break;
			System.out.println("Nazwa nie mo�e by� pusta !");
		}
		return x;
	}

	public static void main(String[] args) {
		ZarzadzanieFirmami zarzadzanieFirmami = new ZarzadzanieFirmami();
		zarzadzanieFirmami.rozpocznijProgam();

	}

}
