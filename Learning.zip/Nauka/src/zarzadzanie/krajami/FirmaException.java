package zarzadzanie.krajami;

public class FirmaException extends Exception {

	public FirmaException(String message) {
		super(message);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
