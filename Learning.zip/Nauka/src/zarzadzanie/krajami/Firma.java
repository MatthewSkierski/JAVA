package zarzadzanie.krajami;



public class Firma {
	
	private String nazwa;
	private double kursStartowy;
	private double kursKoncowy;

	public Firma(String nazwa, double kursStartowy, double kursKoncowy) throws FirmaException {
		super();
		if (nazwa == null || nazwa.trim().equals("")) {
			throw new FirmaException("Nazwa firmy musi by� podana");
		}
		if (kursStartowy < 0) {
			throw new FirmaException("Kurs nie mo�e by� ujemny lub zerowy");
		}
		if (kursKoncowy < 0) {
			throw new FirmaException("Kurs nie mo�e by� ujemny lub zerowy");
		}
		this.nazwa = nazwa;
		this.kursKoncowy = kursKoncowy;
		this.kursStartowy = kursStartowy;

	}

	public double wspolczynnik() {
		double wspolczynnik = this.kursStartowy - this.kursKoncowy;
		return wspolczynnik;
	}

	public double wspolczynnikStraty() {
		double wspolczynnik = this.kursKoncowy - this.kursStartowy;
		return wspolczynnik;
	}

	public String getNazwa() {
		return nazwa;
	}

	public double getKursStartowy() {
		return kursStartowy;
	}

	public double getKursKoncowy() {
		return kursKoncowy;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nazwa == null) ? 0 : nazwa.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Firma other = (Firma) obj;
		if (nazwa == null) {
			if (other.nazwa != null)
				return false;
		} else if (!nazwa.equals(other.nazwa))
			return false;
		return true;
	}


}
