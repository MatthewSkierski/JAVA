package Nauka_semII;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Ramka extends JFrame implements ActionListener {
 public Ramka() {
	 setTitle("Aplikacja do Nauki");
	 add(przycisk);
	 add(przyciskDwa);
	 add(pole);
	 przycisk.addActionListener(this);
	 przyciskDwa.addActionListener(this);
	 
	 
	 GridLayout przyciski = new GridLayout(1,3);
	 setLayout(przyciski);
	 
	 
	 pack();
	 setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 }
 public JButton przycisk = new JButton("Klikasz na w�asne ryzyko");
 public JButton przyciskDwa = new JButton("Przycisk Dwa");
 public JTextField pole = new JTextField();

public void actionPerformed(ActionEvent e) {
    Object zrodlo = e.getSource();
    if(zrodlo == przycisk) {
    	JOptionPane.showMessageDialog(null, "Dzia�a");
    }
    if (zrodlo == przyciskDwa){
    	pole.setText("Klikni�te POGU");
    }
		
	}
	
}

