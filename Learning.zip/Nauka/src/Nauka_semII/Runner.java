package Nauka_semII;

public class Runner {

	public static void main(String[] args) {
	Ramka mojaRamka = new Ramka();
	mojaRamka.setVisible(true);

	}

}
