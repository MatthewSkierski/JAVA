package Nauka_SemII_Dokumenty;

public class Dokument {
	String tytul;
	String tresc;
	public String getTytul() {
		return tytul;
	}
	public void setTytul(String tytul) {
		this.tytul = tytul;
	}
	public String getTresc() {
		return tresc;
	}
	public void setTresc(String tresc) {
		this.tresc = tresc;
	}
	public Dokument(String tytul,String tresc) {
		super();
		this.tresc = tresc;
		this.tytul = tytul;
	}

}
