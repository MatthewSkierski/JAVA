package Nauka_SemII_Dokumenty;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;



public class Ramka extends JFrame implements ActionListener {

	public ArrayList<Dokument> dokumenty;
	public ArrayList<JTextField> polaTekstoweTytuly;
	public ArrayList<JTextField> polaTekstoweTresci;
	public ArrayList<JButton> przyciski;
	public ArrayList<JButton> przyciskiZmien;
	public ArrayList<JButton> przyciskiWGore;
	public ArrayList<JButton> przyciskiWDol;
	public JPanel mojPanel;
	JButton przyciskDodaj;
	JButton przyciskZapisz;
	JButton przyciskOdczytaj;

	public Ramka(ArrayList<Dokument> dokumenty) {
		this.dokumenty = dokumenty;
		mojPanel = new JPanel();
		add(mojPanel);
		wypelnijPanel();

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

	private void wypelnijPanel() {
		mojPanel.removeAll();
		GridLayout ustawienie = new GridLayout(dokumenty.size() + 1, 2);
		mojPanel.setLayout(ustawienie);
		polaTekstoweTresci = new ArrayList<JTextField>();
		polaTekstoweTytuly = new ArrayList<JTextField>();
		przyciskiWGore = new ArrayList<JButton>();
		przyciskiWDol = new ArrayList<JButton>();
		przyciski = new ArrayList<JButton>();
		przyciskiZmien = new ArrayList<JButton>();

		for (Dokument dokument : dokumenty) {
			JTextField tytul = new JTextField();
			mojPanel.add(tytul);
			tytul.setText(dokument.getTytul());
			polaTekstoweTytuly.add(tytul);

			JTextField tresc = new JTextField();
			mojPanel.add(tresc);
			tresc.setText(dokument.getTresc());
			polaTekstoweTresci.add(tresc);

			JButton przyciskUsun = new JButton("Usu�");
			przyciski.add(przyciskUsun);
			mojPanel.add(przyciskUsun);
			przyciskUsun.addActionListener(this);

			JButton przyciskZmien = new JButton("Zmie�");
			przyciskiZmien.add(przyciskZmien);
			mojPanel.add(przyciskZmien);
			przyciskZmien.addActionListener(this);
			
			JButton przyciskWGore = new JButton ("W G�r�");
			przyciskiWGore.add(przyciskWGore);
			mojPanel.add(przyciskWGore);
			przyciskWGore.addActionListener(this);
			
			JButton przyciskWDol = new JButton ("W D�");
			przyciskiWDol.add(przyciskWDol);
			mojPanel.add(przyciskWDol);
			przyciskWDol.addActionListener(this);

		}
		przyciskDodaj = new JButton("Dodaj");
		mojPanel.add(przyciskDodaj);
		przyciskDodaj.addActionListener(this);
		przyciskZapisz = new JButton("zapisz");
		mojPanel.add(przyciskZapisz);
		przyciskZapisz.addActionListener(this);
		przyciskOdczytaj = new JButton("Odczytaj");
		mojPanel.add(przyciskOdczytaj);
		przyciskOdczytaj.addActionListener(this);
		pack();
	}

	public void actionPerformed(ActionEvent e) {
		Object zrodlo = e.getSource();

		int i = przyciski.indexOf(zrodlo);
		int n = przyciskiZmien.indexOf(zrodlo);
		int d = przyciskiWDol.indexOf(zrodlo);
		int w = przyciskiWGore.indexOf(zrodlo);
		if(i>-1) {
			dokumenty.remove(i);
			wypelnijPanel();
		}
		if(d>-1) {
			Dokument dokument = dokumenty.get(d);
			dokumenty.remove(d);
			dokumenty.add(d+1, dokument);
			wypelnijPanel();
		}
		if(w>-1) {
			Dokument dokument = dokumenty.get(w);
			dokumenty.remove(w);
			dokumenty.add(w-1, dokument);
			wypelnijPanel();
		}
		if(n>-1) {		
		Dokument staryDokument = dokumenty.get(n);
			String tytul = JOptionPane.showInputDialog(null, "Nazwa nowego dokumentu", "Nowy dokument",
					JOptionPane.OK_CANCEL_OPTION);
			staryDokument.setTytul(tytul);
			String tresc = JOptionPane.showInputDialog(null, "Nazwa nowego dokumentu", "Nowy dokument",
					JOptionPane.OK_CANCEL_OPTION);
			staryDokument.setTresc(tresc);
			wypelnijPanel();
		}

		if (zrodlo == przyciskDodaj) {
			String tytul = JOptionPane.showInputDialog(null, "Nazwa dokumentu", "Nowy dokument",
					JOptionPane.OK_CANCEL_OPTION);
			if (tytul != null) {
				String tresc = JOptionPane.showInputDialog(null, "Tresc dokumentu", "Nowy dokument",
						JOptionPane.OK_CANCEL_OPTION);
				if (tresc != null) {
					Dokument dokumentNowy = new Dokument(tytul, tresc);
					dokumenty.add(dokumentNowy);
					wypelnijPanel();
				}
			}

			
			
			
		}
		if(zrodlo == przyciskZapisz) {
			File file = new File("dokumenty.txt");
			try {
				FileWriter fwriter = new FileWriter(file);
				BufferedWriter bwriter = new BufferedWriter(fwriter);
				for (int h = 0; h < dokumenty.size(); h++) {
					bwriter.write("Dokument\n");
					bwriter.write(dokumenty.get(h).getTytul() + "\n");
					bwriter.write(dokumenty.get(h).getTresc() + "\n");
				}
				bwriter.close();
			} catch (IOException e1) {

				e1.printStackTrace();
			}
			System.out.println("Documents have been saved to the file");
			wypelnijPanel();
		}
		
		if(zrodlo == przyciskOdczytaj) {
			File file = new File("dokumenty.txt");
			try {
				FileReader freader = new FileReader(file);
				BufferedReader breader = new BufferedReader(freader);
				dokumenty.clear();
				String line;
				while ((line = breader.readLine()) != null) {
					if (line.equals("Dokument")) {
						String tytul = breader.readLine();
						String tresc = breader.readLine();
						Dokument mojDokumentTekstowy = new Dokument(tytul, tresc);
						dokumenty.add(mojDokumentTekstowy);
					}
				}
				breader.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			System.out.println("Documents have been loaded from the file");
			wypelnijPanel();
		}
	}

}
