package Nauka_SemII_Dokumenty;

import java.util.ArrayList;

public class Runner {

	public static void main(String[] args) {
		ArrayList<Dokument> dokumenty = new ArrayList<Dokument>();
		
		Dokument dokumentJeden = new Dokument("Jeden", "Jeden");
		Dokument dokumentDwa = new Dokument("DWA", "DWA");
		Dokument dokumentTrzy = new Dokument("TRZY", "TRZY");
		
		dokumenty.add(dokumentJeden);
		dokumenty.add(dokumentDwa);
		dokumenty.add(dokumentTrzy);
		
		Ramka ramka = new Ramka(dokumenty);
		ramka.setVisible(true);

	}

}
