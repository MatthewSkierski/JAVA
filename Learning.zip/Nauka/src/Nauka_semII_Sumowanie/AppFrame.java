package Nauka_semII_Sumowanie;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import java.util.InputMismatchException;
import java.util.MissingFormatArgumentException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class AppFrame extends JFrame implements ActionListener {

	public JTextField poleUp = new JTextField();
	public JButton liczButton = new JButton("Oblicz");
	public JTextField poleDown = new JTextField();
	public 	int x;
	public String text;
	
	public JPanel panel = new JPanel();
	
	private static final long serialVersionUID = 1L;
	
	public AppFrame() {
		setTitle("Obliczanie Liczby");
		setSize(700,700);		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
		setBackground(Color.BLUE);
		setLocationRelativeTo(null);
		
		initGui();
	}

	private void initGui() {
		this.setLayout(new BorderLayout());
		
		this.add(liczButton, BorderLayout.CENTER);
		liczButton.addActionListener(this);
		this.add(poleDown, BorderLayout.SOUTH);
		this.add(poleUp,BorderLayout.NORTH);
		
		
		
		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object zrodlo = e.getSource();
		if(zrodlo == liczButton) {
			fibonacciDwa();
		}
		
	}
	private int fibonacciDwa() {
		int wynik = 0;
		int a = 0;
		int b = 1;
		 
	
		
		try {
			text= this.poleUp.getText();
			x = Integer.parseInt(text);
		
	
		}catch(NumberFormatException e) {
			if( text == "") {
				this.poleDown.setText("Brak numeru wyrazu");
			}
			if(x <= 0 ) {
				 this.poleDown.setText("Podaj liczb� dodatni�");
			}
			
		}
		if(x==0) {
			return a;
		}else if(x==1) {
			
		
			return b;
	}else{
		for (int i = 2; i <= x; i++) {
			wynik = a + b;
			a = b;
			b = wynik;
		}

		
		String textDwa = String.valueOf(wynik);
		this.poleDown.setText(textDwa);
		return wynik;
	}
		
		
	
	}
}
	

	
	


