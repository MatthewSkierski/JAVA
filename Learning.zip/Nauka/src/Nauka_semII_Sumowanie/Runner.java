package Nauka_semII_Sumowanie;

import javax.swing.JFrame;


public class Runner {

	public static void main(String[] args) {
		AppFrame f = new AppFrame();
				f.setVisible(true);

	}

}
