package pila;

import java.util.Scanner;

public class Metody {

	private static int liczbaJeden = 5;
	private static int liczbaDwa = 4;
	private static int liczbaTrzy = 3;

	public static int wiek() {
		int wiek = 20;
		System.out.println(wiek);
		return wiek;

	}

	public static String imie() {
		String imie = "Mateusz";
		System.out.println(imie);
		return imie;
	}

	public static void liczby(int liczbaJeden, int liczbaDwa) {
		int roznica = liczbaJeden - liczbaDwa;
		int suma = liczbaJeden + liczbaDwa;
		int iloczyn = liczbaJeden * liczbaDwa;
		System.out.println("R�nica wynosi = " + roznica + " Suma wynosi = " + suma + " Iloczyn wyonsi =" + iloczyn);
	}

	public static boolean czyParzysta(int liczbaJeden) {

		if (liczbaJeden % 2 == 1) {
			System.out.println("Liczba Nieparzysta");
			return false;
		} else {
			System.out.println("Liczba Parzysta");
			return true;
		}

	}

	public static boolean czyDzieli(int liczbaJeden) {
		if (liczbaJeden % 3 == 0 || liczbaJeden % 5 == 0) {
			System.out.println("Liczba dzieli si� przez 5 i 3");
			return true;
		} else {
			System.out.println("liczba nie dzieli si� przez 3 i 5");
			return false;
		}
	}

	public static int potengowanie(int liczbaJeden) {
		int liczbaPotengowana = liczbaJeden * liczbaJeden * liczbaJeden;
		System.out.println("liczba do trzeciej pot�gi wynosi =" + liczbaPotengowana);
		return liczbaPotengowana;
	}

	public static double pierwiastkowanie(int liczbaJeden) {
		double liczbaPierwiastkowana = Math.sqrt(liczbaJeden);
		return liczbaPierwiastkowana;
	}

	public static boolean czyProstokatny(int liczbaJeden, int liczbaDwa, int liczbaTrzy) {
		if (Math.pow(liczbaJeden, 2) + Math.pow(liczbaDwa, 2) == Math.pow(liczbaTrzy, 2)) {
			System.out.println("Liczby tworz� tr�jk�t prostok�tny (1,2,3)");
			return true;
		}
		if (Math.pow(liczbaTrzy, 2) + Math.pow(liczbaDwa, 2) == Math.pow(liczbaJeden, 2)) {
			System.out.println("Liczby tworz� tr�jk�t prostok�tny (2,3,1)");
			return true;
		}
		if (Math.pow(liczbaJeden, 2) + Math.pow(liczbaTrzy, 2) == Math.pow(liczbaDwa, 2)) {
			System.out.println("Liczby tworz� tr�jk�t prostok�tny (1,3,2)");
			return true;
		}
		System.out.println("Liczby nie tworz� tr�jk�ta prostok�tnego");
		return false;

	}

	public static void main(String[] args) {
		imie();
		wiek();
		liczby(liczbaJeden, liczbaDwa);
		czyParzysta(liczbaDwa);
		czyDzieli(liczbaJeden);
		potengowanie(liczbaJeden);
		czyProstokatny(liczbaJeden, liczbaDwa, liczbaTrzy);
		duzaLitera();

	}

	private static void duzaLitera() {
		Scanner scan = new Scanner(System.in);
		String x = scan.next().toUpperCase();
	
	
		System.out.println(x);
		

	}
}
