package pila;

public class Human {
	int age = 5;
	int weight = 98;
	int height = 153;
	String name = "Stefan";
	String male = "Male";

	public int getAge() {
		return age;
	}

	public int getWeight() {
		return weight;
	}

	public int getHeight() {
		return height;
	}

	public String getName() {
		return name;
	}

	public String getMale() {
		return male;
	}

	public static void main(String[] args) {

	}

}
