package pila;

public class Prostokont {
	double szerokosc = 5.36;
	double dlugosc = 8.75;

	public static double Pole(double szerokosc, double dlugosc) {
		double pole = szerokosc * dlugosc;
		System.out.println("Pole wynosi " + pole);
		return pole;
	}

	public static double Obwod(double dlugosc, double szerokosc) {
		double obwod = dlugosc * 2 + szerokosc * 2;
		return obwod;
	}
	public static double DlugoscPrzekontnej(double dlugosc, double szerokosc) {
		double przekontnaWPotendze = Math.pow(dlugosc, 2)+Math.pow(szerokosc, 2);
		 double przekontna = Math.sqrt(przekontnaWPotendze);
		return przekontna;
	}
}
