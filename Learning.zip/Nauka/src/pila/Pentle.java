package pila;

public class Pentle {
    static int licznik = 4;
    public static void wypisywanie(int licznik) {
		while( licznik != 10) {
			System.out.println("licznik "+licznik);
			licznik++;
		}
    	
    }
   public static void wypisywanieDwa(int licznik) {
	   for(int i = 0; i <= licznik; i++) {
		   System.out.println("LicznikDwa"+ i);
		   
	   }
   }
	
	public static void main(String[] args) {
      wypisywanie(licznik);
      wypisywanieDwa(licznik);

	}

}
