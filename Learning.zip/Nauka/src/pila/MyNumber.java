package pila;

public class MyNumber {

	int liczba = 14;

	MyNumber(int liczba) {
		isOdd(liczba);
		isEven(liczba);
		sqrt(liczba);
		

	}

	private double sqrt(int liczba) {
		double pierwiastek = Math.sqrt(liczba);
				return pierwiastek;
		
	}

	private boolean isEven(int liczba) {
		if (liczba % 2 == 0) {
			System.out.println("liczba jest parzysta");
			return true;
		}
		return false;

	}

	private boolean isOdd(int liczba) {
		if (liczba % 2 == 1) {
			System.out.println("Liczba jest nie parzysta");
			return true;
		}
		return false;
	}

}
