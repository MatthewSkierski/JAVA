package Ruletka;

public class RuletkaException extends Exception {
	public RuletkaException(String message) {
		super(message);

}
}
