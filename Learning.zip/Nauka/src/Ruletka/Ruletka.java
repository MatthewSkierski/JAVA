package Ruletka;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import java.util.Random;
import java.util.Scanner;

public class Ruletka {
	int liczbaMonet = 300;
	private ArrayList<PoleRuletki> polaRuletki = new ArrayList<PoleRuletki>();
	private boolean wlaczony = true;
	private Scanner scan = new Scanner(System.in);
	Random generator = new Random();

	public void wlacznik() {
		try {
			wgrajDane();
		} catch (IOException e) {

			e.printStackTrace();
		} catch (RuletkaException e) {

			e.printStackTrace();
		}
		if (wlaczony == true) {
			
			czyMozeGrac();
			wyswietlMenu();
			pobierzOpcje();
			

		}
	}

	private void czyMozeGrac() {
		if (liczbaMonet <= 0) {
			System.out.println("Nie masz ju� monet do widzenia");
		}
		
	}

	private void pobierzOpcje() {
		String wybor = scan.nextLine();
		wybor.toLowerCase();		
		switch(wybor) {
		case "tak":
			pobierzWpisowe();
			obstawKolor();
			break;
		case "nie":
			System.out.println("Do widzenia");
			wlaczony = false;
			break;
			default:
				System.out.println("Podaj poprawn� informacj�");
				pobierzOpcje();

		
			
		}

	}

	private int pobierzWpisowe() {
		liczbaMonet -= 30;
		return liczbaMonet;
	}

	private void obstawKolor() {

		System.out.println("Podaj kolor Black/Red");
		String wybor = scan.next();
		wybor.toUpperCase();	
		
		
		obstawLiczbe();

	}

	private void obstawLiczbe() {
		System.out.println("Czy obstawi� liczby wi�ksze od 10 Tak/Nie");
		String wybor = scan.next();
		wybor.toUpperCase();
		
		losowaniePola();
		
	}

	private PoleRuletki losowaniePola() {
	return this.polaRuletki.get(generator.nextInt(this.polaRuletki.size()));
	
		
		
	}
	private void wynikGry() {
		PoleRuletki wylosowane = losowaniePola();
		System.out.println(wylosowane.getNazwa()+ wylosowane.getNumer());
	}

	private void wyswietlMenu() {
		System.out.println("Czy chcesz zagra� w ruletk� ?");
		System.out.println("Tak/Nie");

	}

	private void wgrajDane() throws IOException, RuletkaException {
		File plik = new File("pliki/kolo.txt");
		FileReader fr = new FileReader(plik);
		BufferedReader br = new BufferedReader(fr);
		ArrayList<PoleRuletki> polaRuletki = new ArrayList<PoleRuletki>();

		for (String linia = br.readLine(); linia != null; linia = br.readLine()) {
			String[] daneRuletki = linia.split(";");

			String numerNazwa = daneRuletki[0];
			int numerLiczba = Integer.parseInt(numerNazwa);
			String kolor = daneRuletki[1];
			PoleRuletki poleRuletki;

			poleRuletki = new PoleRuletki(kolor, numerLiczba);
			polaRuletki.add(poleRuletki);

		}
		br.close();
	}
	public static void main(String[] args) {
		Ruletka gra = new Ruletka();
		gra.wlacznik();
	}

}
