package Ruletka;

public class PoleRuletki {
	String kolor;
	int numer;
	public PoleRuletki(String kolor, int numer) {
		this.kolor= kolor;
		this.numer = numer;
	}
	public String getNazwa() {
		return kolor;
	}
	public int getNumer() {
		return numer;
	}

}
