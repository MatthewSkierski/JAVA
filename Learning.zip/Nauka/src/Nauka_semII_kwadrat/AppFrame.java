package Nauka_semII_kwadrat;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class AppFrame extends JFrame implements ActionListener {

	
	private static final long serialVersionUID = 1L;

	public JPanel mojPanel = new JPanel();
	
	public JButton rightButton = new JButton("Prawo");
	public JButton leftButton = new JButton("Lewo");
	public JButton upButton = new JButton("G�ra");
	public JButton downButton = new JButton("D�");
	public AnimationPanel animArea;
	
	public AppFrame() {
		setTitle("animation");
		setSize(700,700);
		setResizable(false);
		setBackground(Color.BLUE);
		setLocationRelativeTo(null);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		initGui();
		
	}

	private void initGui() {
		this.setLayout(new BorderLayout());
		
		animArea = new AnimationPanel();

		this.add(animArea,BorderLayout.CENTER);
		
		mojPanel.add(rightButton,BorderLayout.SOUTH);
		rightButton.addActionListener(this);
		mojPanel.add(leftButton,BorderLayout.SOUTH);
		leftButton.addActionListener(this);
		mojPanel.add(downButton,BorderLayout.SOUTH);
		downButton.addActionListener(this);
		mojPanel.add(upButton,BorderLayout.SOUTH);
		upButton.addActionListener(this);
		this.add(mojPanel, BorderLayout.SOUTH);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object zrodlo = e.getSource();
		if(zrodlo == downButton) {
			
		}
		if(zrodlo == upButton) {
			
		}
		if(zrodlo == leftButton) {
			
		}
		if(zrodlo == rightButton) {
			
		}
	}

}
