package Nauka_semII_kwadrat;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

public class AnimationPanel extends JPanel {

	public double x,y;
	public boolean isPaused;
	public int  refreshRate = 10;
	public AnimationPanel() {
		//repaint
		setBackground(Color.WHITE);
		setDoubleBuffered(true);
	}
	
	public void paint(Graphics g) {
		super.paint(g);
		
		Graphics2D g2 = (Graphics2D) g;
		g2.setColor(Color.BLACK);
		g2.drawRect((int)x,(int) y, 40,40 );
		
	}
	public void movement() {

		

		// if (y > this.getWidth()) {
		// y = 0.0;
		// x = 0.0;
		// }
	}

	public void run() {

		while (true) {

			if (!isPaused) {
				movement();
				repaint();// powt�rzenie metody paint wygenerowane
			}

			try {
				Thread.sleep(refreshRate); // usypianie w�tku
			} catch (InterruptedException e) {
				System.out.println("interrupted");
			}

		}
	}
}
