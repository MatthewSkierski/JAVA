package sklep;

public class Pracownik {
	String imie;
	String nazwisko;
	int wiek;
	String stanowisko;

	public Pracownik( String imie, String nazwisko,int wiek, String stanowisko) throws SklepException {

		if (wiek < 0) {
			throw new SklepException("Wiek nie mo�e by� ujemny");
		}
		if (imie == null) {
			throw new SklepException("Pracownik musi mie� imi�");
		}
		if (nazwisko == null) {
			throw new SklepException("Pracownik musi mie� nazwisko");

		}
		if (stanowisko == null) {
			throw new SklepException("Pracownik musi mie� stanowisko");

		}
		this.wiek = wiek;
		this.imie = imie;
		this.nazwisko = nazwisko;
		this.stanowisko= stanowisko;

	}

	public String getImie() {
		return imie;
	}

	public String getStanowisko() {
		return stanowisko;
	}

	public String getNazwisko() {
		return nazwisko;
	}

	public int getWiek() {
		return wiek;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((imie == null) ? 0 : imie.hashCode());
		result = prime * result + ((nazwisko == null) ? 0 : nazwisko.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pracownik other = (Pracownik) obj;
		if (imie == null) {
			if (other.imie != null)
				return false;
		} else if (!imie.equals(other.imie))
			return false;
		if (nazwisko == null) {
			if (other.nazwisko != null)
				return false;
		} else if (!nazwisko.equals(other.nazwisko))
			return false;
		return true;
	}
	

}
