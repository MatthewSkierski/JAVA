package sklep;

public class SklepException extends Exception {
	
	public SklepException(String message) {
		super (message);
	}
	

	
	private static final long serialVersionUID = 1L;

}
