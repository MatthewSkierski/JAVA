package sklep;

public class Produkt {
	String nazwa;
	double cena;
	String marka;

	public Produkt(String nazwa, String marka, double cena) throws SklepException {
		if (nazwa == null) {
			throw new SklepException("Produkt musi mie� nazw�");
		}
		if (marka == null) {
			throw new SklepException("Produkt musi by� danej marki");
		}
		if (cena < 0) {
			throw new SklepException("Cena musi by� dodatni� liczb�");
		}
		this.cena = cena;
		this.marka = marka;
		this.nazwa = nazwa;

	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nazwa == null) ? 0 : nazwa.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Produkt other = (Produkt) obj;
		if (nazwa == null) {
			if (other.nazwa != null)
				return false;
		} else if (!nazwa.equals(other.nazwa))
			return false;
		return true;
	}

	public String getNazwa() {
		return nazwa;
	}

	public double getCena() {
		return cena;
	}

	public String getMarka() {
		return marka;
	}

}
