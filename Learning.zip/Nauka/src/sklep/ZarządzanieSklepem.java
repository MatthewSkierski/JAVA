package sklep;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Zarz�dzanieSklepem {
	private boolean wlaczony = true;
	private ArrayList<Pracownik> pracownicy = new ArrayList<Pracownik>();
	private ArrayList<Produkt> produkty = new ArrayList<Produkt>();
	private Scanner scan = new Scanner(System.in);

	public void wlacznik() {
		try {
			wgrajDane();

		} catch (IOException e1) {

			e1.printStackTrace();
		}
		while (wlaczony) {

			wyswietlMenu();
			try {
				wykonajOpcje();
			} catch (NumberFormatException e) {
				System.err.println("Podaj liczb� ca�kowit� " + e.getMessage());

			}

		}
	}

	private void wgrajDane() throws IOException {
		File plik = new File("pliki/Pracownicy.txt");
		FileReader fr = new FileReader(plik);
		BufferedReader br = new BufferedReader(fr);
		List<Pracownik> pracownicy = new ArrayList<Pracownik>();

		for (String linia = br.readLine(); linia != null; linia = br.readLine()) {
			String[] danePracownika = linia.split(";");

			String imie = danePracownika[0];
			String nazwisko = danePracownika[1];
			int wiek = Integer.parseInt(danePracownika[2]);
			String stanowisko = danePracownika[3];

			Pracownik pracownik;
			try {
				pracownik = new Pracownik(imie, nazwisko, wiek, stanowisko);
				pracownicy.add(pracownik);

			} catch (SklepException e) {
				System.err.println(e.getMessage());

			}

		}
		br.close();

		this.pracownicy = (ArrayList<Pracownik>) pracownicy;
		
		File plikdwa = new File("pliki/Produkty.txt");
		FileReader frd = new FileReader(plikdwa);
		BufferedReader brd = new BufferedReader(frd);
		List<Produkt> produkty = new ArrayList<Produkt>();

		for (String linia = brd.readLine(); linia != null; linia = brd.readLine()) {
			String[] daneProduktu = linia.split(";");

			String nazwa = daneProduktu[0];
			String marka = daneProduktu[1];
			double cena = Double.parseDouble(daneProduktu[2]);

			Produkt produkt;
			try {
				produkt = new Produkt(nazwa, marka, cena);
				produkty.add(produkt);

			} catch (SklepException e) {
				System.err.println(e.getMessage());

			}

		}

		this.produkty = (ArrayList<Produkt>) produkty;
		brd.close();

	}

	private void wykonajOpcje() {
		System.out.println("Podaj numer opcji");
		String opcja = scan.next();
		int opcjaInt = Integer.parseInt(opcja);
		switch (opcjaInt) {
		case 1:
			wyswietlListePracownikow();

			break;
		case 2:
			wyswietlListeProdoktow();
			break;
		case 3:
			posortujPracownikow();
			break;
		case 4:
			posortujTowarAlfabetycznie();
			break;

		case 5:
			posortujTowarCenowo();
			System.out.println("Podaj poprawn� liczb�");
			break;
		case 6:
			try {
				dodajTowar();
			} catch (SklepException e) {

				e.printStackTrace();
			}
			break;
		case 7:
			try {
				usunTowar();
			} catch (SklepException e1) {

				e1.printStackTrace();
			}
			break;

		case 8:
			try {
				dodajPracownika();
			} catch (SklepException e) {

				e.printStackTrace();
			}
			break;
		case 9:
			try {
				usunPracownika();
			} catch (SklepException e) {

				e.printStackTrace();
			}
		case 10:
			wlaczony = false;

		default:
		}

	}

	private int askInt(int min, int max, String pytanie) {
		int x;
		while (true) {
			try {
				System.out.print(pytanie + ": ");
				x = Integer.parseInt(scan.next());
				if (x <= max && x >= min)
					break;
				System.out.println("Liczba musi byc z przedzialu " + min + "-" + max + '!');
			} catch (NumberFormatException e) {
				System.err.println("Podano nieprawidlowa liczbe!");
			}
		}
		return x;
	}

	private double askDouble(double min, double max, String pytanie) {
		double x;
		while (true) {
			try {
				System.out.print(pytanie + ": ");
				x = Double.parseDouble(scan.next());
				if (x <= max && x >= min)
					break;
				System.out.println("Liczba musi byc z przedzialu " + min + "-" + max + '!');
			} catch (NumberFormatException e) {
				System.err.println("Podano nieprawidlowa liczbe!");
			}
		}
		return x;
	}

	private String askString(String pytanie) {
		String x;
		while (true) {
			System.out.print(pytanie + ": ");
			x = scan.next();

			if (!pytanie.isBlank())
				break;
			System.out.println("Odpowiedz nie moze byc pusta!");
		}
		return x;
	}

	private void usunPracownika() throws SklepException {
		String imie = askString("Podaj imi� pracownika");
		String nazwisko = askString("Podaj nazwisko pracownika");
		Pracownik pracownik = new Pracownik(imie, nazwisko, 0, "X");
		pracownicy.remove(pracownik);
		System.out.println("Usuni�to pracownika o imieniu " + imie + " i nazwisku " + nazwisko);
	}

	private void usunTowar() throws SklepException {
		System.out.println("Podaj nazw� produktu, kt�ry chcesz usun��");
		wyswietlListeProdoktow();
		String nazwa = scan.next();
		Produkt produkt = new Produkt(nazwa, "X", 0);
		produkty.remove(produkt);
		System.out.println("Usuni�to produkt " + nazwa);

	}

	private void dodajPracownika() throws SklepException {
		String imie = askString("Podaj imi� pracownika");
		String nazwisko = askString("Podaj nazwisko pracownika");
		int wiek = askInt(0, 150, "Podaj wiek pracownika");
		String stanowisko = askString("Podaj stanowisko pracownika");

		Pracownik p = new Pracownik(imie, nazwisko, wiek, stanowisko);
		pracownicy.add(p);
		System.out.println("Dodano pracownika");

	}

	private void dodajTowar() throws SklepException {
		String nazwa = askString("Podaj nazw� towaru ");
		String marka = askString("Podaj mark� towaru");
		double cena = askDouble(0, 99999.99999, "Podaj cen� towaru");
		Produkt p = new Produkt(nazwa, marka, cena);
		produkty.add(p);
		System.out.println("Dodano produkt " + p.toString());

	}

	private void posortujTowarCenowo() {
		Comparator<Produkt> comp = Comparator.comparingDouble(Produkt::getCena);
		Collections.sort(produkty, comp);

	}

	private void posortujTowarAlfabetycznie() {
		Comparator<Produkt> comp = Comparator.comparing(Produkt::getNazwa);
		Collections.sort(produkty, comp);

	}

	private void posortujPracownikow() {
		Comparator<Pracownik> comp = Comparator.comparing(Pracownik::getImie);
		Collections.sort(pracownicy, comp);

	}

	private void wyswietlListeProdoktow() {
		for (Produkt produkt : produkty) {
			String info = "Nazwa Produktu " + produkt.getNazwa() + " Marka " + produkt.getMarka() + " Cena "
					+ produkt.getCena();
			System.out.println(info);
		}

	}

	private void wyswietlListePracownikow() {
		for (Pracownik pracownik : pracownicy) {
			String info = "Imi� " + pracownik.getImie() + " Nazwisko " + pracownik.getNazwisko() + " Wiek "
					+ pracownik.getWiek() + " Stanowisko " + pracownik.getStanowisko();
			System.out.println(info);

		}

	}

	private void wyswietlMenu() {
		StringBuilder sb = new StringBuilder();
		sb.append("1. Wy�wietl list� pracownik�w");
		sb.append('\n');
		sb.append("2. Wy�wietl list� towar�w");
		sb.append('\n');
		sb.append("3. Posortuj list� pracownik�w alfabetycznie");
		sb.append('\n');
		sb.append("4. Posortuj list� towar�w alfabetycznie");
		sb.append('\n');
		sb.append("5. Posortuj list� towar�w Cenowo");
		sb.append('\n');
		sb.append("6. Dodaj towar");
		sb.append('\n');
		sb.append("7. Usu� towar");
		sb.append('\n');
		sb.append("8. Dodaj pracownika");
		sb.append('\n');
		sb.append("9. Usu� pracownika");
		sb.append('\n');
		sb.append("10. Zako�cz dzia�anie programu");
		sb.append('\n');

		System.out.println(sb.toString());

	}

	public static void main(String[] args) {
		Zarz�dzanieSklepem zarzadzanieSklepem = new Zarz�dzanieSklepem();
		zarzadzanieSklepem.wlacznik();

	}

}
