package RysowanieKol;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

public class AnimationPanel extends JPanel {
	

	private static final long serialVersionUID = 1L;
	public boolean isPaused = false;
	private long refreshRate = 10;
	private double x ;
	private double y;
	private double kat;
	public int z ; 
	public AnimationPanel() {
		setBackground(Color.BLACK);
		setDoubleBuffered(true);
	}
	public void paint(Graphics g) { // musimy to nazwya� paint
		super.paint(g);
		Graphics2D g2 = (Graphics2D) g;
		g2.setColor(Color.YELLOW); 
		for (int i = 0; i < z ;i++) {
	
		g2.fillOval(200, 200,(int) x,60);
		
		}
			
	}
	public void switchAnimationState() {
		isPaused = !isPaused;
	}
	public void run() {

		while (true) {

			if (!isPaused) {
		
				repaint();// powt�rzenie metody paint wygenerowane
			}

			try {
				Thread.sleep(refreshRate); // usypianie w�tku
			} catch (InterruptedException e) {
				System.out.println("interrupted");
			}

		}
	}

public void promienKola(int promienliczba) {
	x = promienliczba;
	repaint();
	
}
public void iloscKol(int iloscliczba) {
     z =	iloscliczba  ;
	repaint();
}


}
