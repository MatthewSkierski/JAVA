package RysowanieKol;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;



public class AppFrame extends JFrame implements ActionListener {
	
	private static final long serialVersionUID = 1L;
	private int promienliczba;

	public AnimationPanel animArea;
	public JTextField polePromien = new JTextField("1");
	public JTextField poleIlosc = new JTextField("1");
	public JTextField poleWynik = new JTextField();
	public JPanel panel = new JPanel();
	public JButton przycisk = new JButton("Od�wie�");
	
	public AppFrame() {

		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		setSize(700,700);
		setTitle("Rysowanie k� ");
		setResizable(false);
		setLocationRelativeTo(null);
		initGui();
	}
	

	private void initGui() {
        this.setLayout(new BorderLayout());		
		animArea = new AnimationPanel();
		this.add(animArea,BorderLayout.CENTER);
		
		panel.add(polePromien);
		panel.add(poleIlosc);
		polePromien.addActionListener(this);
		poleIlosc.addActionListener(this);
		przycisk.addActionListener(this);
		panel.add(przycisk);
		
		panel.add(poleWynik);
		
		
		this.add(panel, BorderLayout.SOUTH);
		obliczWynik();
	}
	public void obliczWynik() {
		double wynik = promienliczba*promienliczba*3.14;
		String wynikSlowo = String.valueOf(wynik);
		poleWynik.setText(wynikSlowo);
		
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		Object zrodlo = e.getSource();
		
		if(zrodlo == przycisk) {
			
				animArea.switchAnimationState();
				obliczWynik();
			}

		
		if(zrodlo == polePromien) {
			String promien = this.polePromien.getText();
			 promienliczba = Integer.parseInt(promien);
			 
			 animArea.promienKola(promienliczba);
				obliczWynik();
		}
		if(zrodlo == poleIlosc) {
			String ilosc = this.poleIlosc.getText();
			int iloscliczba = Integer.parseInt(ilosc);
			
			animArea.iloscKol(iloscliczba);
			obliczWynik();
			
		}
		
	}

}
