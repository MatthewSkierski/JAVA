package odtwarzacz.by.me;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;





public class Playlista {

	private String nazwa;
	private List<Utwor> utwory = new LinkedList<Utwor>();

	public Playlista(String nazwa, List<Utwor> utwory) {
		if (nazwa == null) {
			System.err.println("Nazwa playlisty nie mo�e by� pusta");
		}
	}

	public String getNazwa() {
		return nazwa;
	}
	public Utwor pobierzUtwor(int numer) {
		
		Utwor utwor = utwory.get(numer-1);
		return utwor;			
	}

	public List<Utwor> getUtwory() {
		return utwory;
	}

	public void usunUtwor(int numer) {
		utwory.remove(numer - 1);
	}

	public void dodajUtwor(Utwor utwor) {
		if (utwor == null) {
			System.err.println("Utw�r musi zawiera� poprawde dane");
		} else {
			utwory.add(utwor);
		}
	}

	public Utwor wyswietlUtwor(int numer) {
		Utwor utwor = utwory.get(numer - 1);
		return utwor;
	}
	public  void sortujUtworyAlfabetycznie() {
		Comparator<Utwor> comp = Comparator.comparing(Utwor::getWykonawca).thenComparing(Utwor::getTytul).thenComparing(Utwor::getRokWydania);
		Collections.sort(utwory, comp);
	}
	public void sortujRokiemWydania() {
		Comparator<Utwor> comp = Comparator.comparing(Utwor::getRokWydania).reversed().thenComparing(Utwor::getTytul).thenComparing(Utwor::getWykonawca);
		Collections.sort(utwory,comp);
	}
	public void wyswietlPlayListe() {
		if(utwory.size() == 0 ) {
			System.err.println("Playlista "+ nazwa+ "jest pusta");
		}else {
			System.out.println("Playlista " + nazwa);
			
			for (int i=0; i< utwory.size();i++) {
				System.out.println("\t"+ (i+1) +utwory.get(i));
			}
		}
	}

}
