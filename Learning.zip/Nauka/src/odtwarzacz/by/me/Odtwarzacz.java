package odtwarzacz.by.me;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class Odtwarzacz {
	private boolean wlaczony;
	private Scanner scan = new Scanner(System.in);
	private Map<String, Playlista> playlisty = new HashMap<String, Playlista>();

	private void wloncz() {
		if (wlaczony = true) {
			wyswielMenu();
			int opcja = pobierzLiczbeCalkowita();
			wykonajOpcje(opcja);
		}
	}

	private int pobierzLiczbeCalkowita() {
		String opcjaString = scan.nextLine();
		try {
			int opcja = Integer.parseInt(opcjaString);
			return opcja;
		} catch (NumberFormatException e) {
			System.err.println("To nie jest poprawna liczba " + opcjaString);
			return pobierzLiczbeCalkowita();
		}
	}

	private void wykonajOpcje(int opcja) {

		switch (opcja) {
		case 1:
			wyswietlPlaylisty();
			break;
		case 2:
			wyswietlPlayliste();
			break;
		case 3:
			dodajUtwor();
			break;
		case 4:
			usunUtwor();
		case 9:
			wlaczony = false;
			System.out.println("Koniec pracy programu");
			break;

		default:
			System.err.println("Podaj poprawn� liczb�");
		}
	}

	private void usunUtwor() {
		System.out.println("Podaj nazw� playlisty,  z kt�rej chcesz usun�� utw�r ");
		wyswietlPlaylisty();
		String nazwa = scan.nextLine();
		Playlista playlista = playlisty.get(nazwa.toUpperCase());
		if (playlista != null) {
			playlista.wyswietlPlayListe();
			System.out.println("Podaj numer utworu, kt�ry chcesz usun��");
			int numer = pobierzLiczbeCalkowita();
			Utwor utwor = playlista.pobierzUtwor(numer);
			playlista.usunUtwor(numer);
			System.out.println("Usuni�to utw�r " + utwor);
		} else {
			System.err.println("Playlista" + playlista + " nie istnieje");
		}

	}

	private void dodajUtwor() {
		System.out.println("Podaj nazw� playlisty, do kt�rej chcesz doda� utw�r ");
		wyswietlPlaylisty();
		String nazwa = scan.nextLine();
		Playlista playlista = playlisty.get(nazwa.toUpperCase());
		if (playlista != null) {
			playlista.wyswietlPlayListe();
			System.out.println("Podaj nazw� utworu");
			String tytul = scan.nextLine().toUpperCase();
			System.out.println("Podaj wykonawc� utworu");
			System.out.println("Podaj rok wydania utworu");
			String wykonawca = scan.nextLine().toUpperCase();
			int rokWydania = pobierzLiczbeCalkowita();
			Utwor utwor = new Utwor(tytul, wykonawca, rokWydania);
			playlista.dodajUtwor(utwor);
		} else {
			System.err.println("Playlista" + playlista + " nie istnieje");
		}

	}

	private void wyswietlPlayliste() {
		System.out.println("Podaj nazw� playlisty, kt�r� chcesz wy�wietli� ");
		wyswietlPlaylisty();
		String nazwa = scan.nextLine();
		Playlista playlista = playlisty.get(nazwa.toUpperCase());
		if (playlista != null) {
			playlista.wyswietlPlayListe();
		} else {
			System.err.println("Playlista" + playlista + " nie istnieje");
		}

	}

	private void wyswietlPlaylisty() {
		Set<String> klucze = playlisty.keySet();
		for (String klucz : klucze) {
			System.out.println(klucz);
		}

	}

	private void wyswielMenu() {
		StringBuilder sb = new StringBuilder();
		sb.append("\t Wybierz opcj� : ");
		sb.append("\n 1.Wyswietli� Playlisty");
		sb.append("\n 2.Wyswietl zawarto�� Playlisty");
		sb.append("\n 3.Dodaj utw�r do Playlisty");
		sb.append("\n 4.Usu� utw�r z Playlisty");

		System.out.println(sb.toString());

	}

	public static void main(String[] args) {
		Odtwarzacz odtwarzacz = new Odtwarzacz();
		odtwarzacz.wloncz();

	}

}
