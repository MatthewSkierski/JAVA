package odtwarzacz.by.me;


public class Utwor {
	private String tytul;
	private String wykonawca;
	private int rokWydania;
	
	public Utwor(String tytul,String wykonawca,int rokWydania) {
		if(tytul == null) {
			System.err.println("Nazwa utworu nie mo�e by� pusta");
		}
		if(wykonawca == null) {
			System.err.println("Nazwa wykonwacy nie mo�e by� pusta");
		}
		if(rokWydania<1300) {
			System.err.println("Rok wydania musi by� wi�kszy ni� 1300");
			
		}
	}

	public String getTytul() {
		return tytul;
	}

	public String getWykonawca() {
		return wykonawca;
	}

	public int getRokWydania() {
		return rokWydania;
	}

	@Override
	public String toString() {
		return tytul + "("+wykonawca +") ["+ rokWydania + "]";
	}
	

}
