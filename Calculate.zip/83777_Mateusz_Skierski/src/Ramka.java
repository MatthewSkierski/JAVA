import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;



public class Ramka extends JFrame implements ActionListener {
	
	private static final long serialVersionUID = 1L;
	public JLabel promien = new JLabel("Promie� podstawy");
	public JLabel bok = new JLabel("Bok przekroju osiowego");
	public JLabel polePB = new JLabel("Pole powierzchni bocznej");
	public JLabel polePC = new JLabel("Pole powierzchni ca�kowitej");
	public JLabel objectosc = new JLabel("Obj�to��");
	
	public JPanel panel = new JPanel();

	
	public JButton oblicz = new JButton("Oblicz");
	
	public JTextField promienF = new JTextField();
	public JTextField bokF = new JTextField();
	public JTextField polePBF = new JTextField();
	public JTextField polePCF = new JTextField();
	public JTextField objentoscF = new JTextField();
	
	public Ramka() {
		setTitle("Kalkulator wymiar�w sto�ka");
		setSize(440,230);
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
		initGui();
		
	}

	private void initGui() {
        this.setLayout(new BorderLayout());
		
		

		this.add(oblicz,BorderLayout.NORTH);
		GridLayout ustawienieJeden = new GridLayout(5, 6);
		
		panel.setLayout(ustawienieJeden);
		
		oblicz.addActionListener(this);
		
		
		panel.add(promien);
		panel.add(promienF);
		panel.add(bok);
		panel.add(bokF);
		panel.add(polePB);
		panel.add(polePBF);
		panel.add(polePC);
		panel.add(polePCF);
		panel.add(objectosc);
		panel.add(objentoscF);
		this.add(panel,BorderLayout.SOUTH);
		

		
		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object zrodlo = e.getSource();
		
		if(zrodlo == oblicz) {
			try {
			String wysokoscString = JOptionPane.showInputDialog(null,"Podaj wysoko�� sot�ka", "Wysoko�� sto�ka",JOptionPane.OK_CANCEL_OPTION);
			double wysokosc = Double.parseDouble(wysokoscString);
			String polePodstawyString = JOptionPane.showInputDialog(null,"Podaj pole podstawy sto�ka", "Pole podstawy sto�ka",JOptionPane.OK_CANCEL_OPTION);
			double polePodstawy = Double.parseDouble(polePodstawyString);
			double objentosc = (polePodstawy*wysokosc)/3; // obj�to��
			double promienW = polePodstawy/Math.PI; // przed pierwiastkiem 
			double promien = Math.sqrt(promienW); // ostateczny promie� 
			
			double bokL = Math.pow(wysokosc, 2)+Math.pow(promien, 2);
			double l = Math.sqrt(bokL);
			double polePBA = Math.PI*l*promien; // pole boczne
			double polePC = Math.PI*Math.pow(promien, 2)+Math.PI*promien*l; // pole ca�kowite
			
			String promienText = String.valueOf(promien);
			promienF.setText(promienText);
			String poleCalkowiteText = String.valueOf(polePC);
			polePCF.setText(poleCalkowiteText);
			String objentoscText = String.valueOf(objentosc);
			objentoscF.setText(objentoscText);
			String poleBoczne = String.valueOf(polePBA);
			polePBF.setText(poleBoczne);
			String bokString = String.valueOf(l);
			bokF.setText(bokString);
			bokF.setEditable(false);
			polePBF.setEditable(false);
			objentoscF.setEditable(false);
			polePCF.setEditable(false);
			promienF.setEditable(false);
			
			
			}catch(NumberFormatException x) {
				JOptionPane.showInputDialog("Wprowadz poprawn� warto��");
				
			}
			}
		
	}

}
